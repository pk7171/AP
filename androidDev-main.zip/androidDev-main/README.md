# Android Development Practicals

[1. Implement the below given UI (Responsive) using suitable Layout and
show the name of the button in Toast when clicked](https://github.com/c0delust/androidDev/tree/main/Practical_1)

[2. Implement the below given UI using suitable layout](https://github.com/c0delust/androidDev/tree/main/Practical_2)

[3. Implement the below given UI to Develop an android application to convert
number into binary and hex](https://github.com/c0delust/androidDev/tree/main/Practical_3)

[4. Develop an android application to implement Activity Lifecycle methods
and print Log Info](https://github.com/c0delust/androidDev/tree/main/Practical_4)

[5. Implement the below given UI to Develop an android application to pass
data between activities](https://github.com/c0delust/androidDev/tree/main/Practical_5)

[6. Develop an android application to implement Scrollable List (Java: ListView) and show Toast message when clicked on List Item](https://github.com/c0delust/androidDev/tree/main/Practical_6)

[7. Develop an android application to show Realtime Battery Level on the
Progress Bar using Broadcast Receiver](https://github.com/c0delust/androidDev/tree/main/Practical_7)

[8. Develop an android application to implement Database and perform Create,
Read and Delete operations](https://github.com/c0delust/androidDev/tree/main/Practical_8)

[9. Implement the below given UI to develop an android application that
includes Radio Button](https://github.com/c0delust/androidDev/tree/main/Practical_9)

[10. Implement the below given UI to develop an android application to
Rotate Image](https://github.com/c0delust/androidDev/tree/main/Practical_10)

[11. Develop an android application to implement Google Maps and add
marker on Walchand College of Engineering, Sangli](https://github.com/c0delust/androidDev/tree/main/Practical_11)

[12. Implement the below given UI to develop an android application that
includes Auto-complete Search Bar](https://github.com/c0delust/androidDev/tree/main/Practical_12)

[13. Develop an android application to send SMS](https://github.com/c0delust/androidDev/tree/main/Practical_13)

[14. Develop an android application to implement Date Picker and Time
Picker and print chosen Date & Time](https://github.com/c0delust/androidDev/tree/main/Practical_14)

[15. Develop an android application to show the below table and open
URL in browser when clicked on it](https://github.com/c0delust/androidDev/tree/main/Practical_15)
