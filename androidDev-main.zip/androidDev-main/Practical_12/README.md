# Implement the below given UI to develop an android application that includes Auto-complete Search Bar
