package com.example.practical_13;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText phNum, msgText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        phNum = findViewById(R.id.number);
        msgText = findViewById(R.id.text);

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS}, 0);
        }
    }

    public void send(View view) {
        if(phNum.length() != 0 && msgText.length() != 0) {
            SmsManager smsManager = SmsManager.getDefault();
            String number = phNum.getText().toString().trim();
            String text = msgText.getText().toString().trim();
            smsManager.sendTextMessage(number, null, text, null, null);
            Toast.makeText(this,"SMS Sent", Toast.LENGTH_LONG).show();
        }
    }
}