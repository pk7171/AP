# Develop an android application to send SMS

### Note:
- Add below text in AndroidManifest.xml file under 'manifest' tag:
    < uses-permission android:name="android.permission.SEND_SMS"/>
