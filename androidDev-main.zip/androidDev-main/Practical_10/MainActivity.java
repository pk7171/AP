package com.example.practical_10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    float degree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        degree = 0;
    }

    public void rotate(View view) {
        if(degree != 360 ) {
            degree += 45;
        } else {
            degree = 0;
        }

        imageView.setRotation(degree);
    }
}