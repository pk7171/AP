# Develop an android application to implement Google Maps and add marker on Walchand College of Engineering, Sangli

### Note:
- Create Google Maps Activity Project
- Add below content in AndroidManifest.xml file under '<b>application</b>' tag<br>
    < meta-data
        android:name="com.google.android.geo.API_KEY"<br>
        android:value="AIzaSyDs9d3kT00Ud-kKG304vUjgeOo1UczqogU" />
